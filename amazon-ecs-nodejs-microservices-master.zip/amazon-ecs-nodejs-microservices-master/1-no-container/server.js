const Koa = require('koa');
const Router = require('koa-router');
const axios = require('axios');
const db = require('./db.json');

const app = new Koa();
const router = new Router();

// Log requests
app.use(async (ctx, next) => {
  const start = new Date();
  await next();
  const ms = new Date() - start;
  console.log(`${ctx.method} ${ctx.url} - ${ms}ms`);
});

// Users Routes
router.get('/api/users', async (ctx) => {
  ctx.body = db.users;
});

router.get('/api/users/:userId', async (ctx) => {
  const id = parseInt(ctx.params.userId);
  ctx.body = db.users.find((user) => user.id == id);
});

// Threads Routes
router.get('/api/threads', async (ctx) => {
  ctx.body = db.threads;
});

router.get('/api/threads/:threadId', async (ctx) => {
  const id = parseInt(ctx.params.threadId);
  ctx.body = db.threads.find((thread) => thread.id == id);
});

// Posts Routes
router.get('/api/posts/in-thread/:threadId', async (ctx) => {
  const id = parseInt(ctx.params.threadId);
  ctx.body = db.posts.filter((post) => post.thread == id);
});

router.get('/api/posts/by-user/:userId', async (ctx) => {
  const id = parseInt(ctx.params.userId);
  ctx.body = db.posts.filter((post) => post.user == id);
});

// 🔹 Posts Summary Service - Get total post count
router.get('/api/posts-summary/count', async (ctx) => {
  try {
    const response = await axios.get('http://posts-summary:3001/api/posts-summary/count');
    ctx.body = response.data;
  } catch (error) {
    ctx.status = 500;
    ctx.body = { error: 'Failed to fetch post summary', details: error.message };
  }
});

// 🔹 Peak Hours Analyzer - Get peak activity period
router.get('/api/peak-hours', async (ctx) => {
  try {
    const response = await axios.get('http://peak-hours-analyzer:3002/api/peak-hours');
    ctx.body = response.data;
  } catch (error) {
    ctx.status = 500;
    ctx.body = { error: 'Failed to fetch peak hours', details: error.message };
  }
});

// 🔹 Notification Service - Send Email
router.post('/api/notify', async (ctx) => {
  try {
    const { to, subject, text } = ctx.request.body;
    const response = await axios.post('http://notification:3003/api/notify', { to, subject, text });
    ctx.body = response.data;
  } catch (error) {
    ctx.status = 500;
    ctx.body = { error: 'Failed to send notification', details: error.message };
  }
});

// Health Check
router.get('/api/', async (ctx) => {
  ctx.body = "API ready to receive requests";
});

router.get('/', async (ctx) => {
  ctx.body = "Ready to receive requests";
});

app.use(router.routes());
app.use(router.allowedMethods());

app.listen(3000, () => {
  console.log("Main API Gateway running on port 3000");
});
